﻿using System;
using System.Collections.Generic;

/*
-------------------------------------------
O Desafio:
4 questões para avaliar a capacidade de análise e
resolução de problemas através de algoritmos.

Autor: Rodrigo Galvão
*/

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Boolean continuar = true;
            int questao;
            while (continuar)
            {
                Console.WriteLine(" DESAFIO ALGORITIMO EM C#\r");
                Console.WriteLine("------------------------------------------------------------------------------");
                Console.WriteLine(" 1 [Questão I] | 2 [Questão II] | 3 [Questão III] | 4 [Questão IV] | 0 [Sair]");
                Console.WriteLine("------------------------------------------------------------------------------\n");
                Console.Write("Digite uma opção: ");
                try
                {
                    questao = Convert.ToInt32(Console.ReadLine());
                }
                catch (Exception)
                {
                    questao = 99999;
                }

                if (questao != 0)
                    questoes(questao);
                else if (questao == 0)
                    continuar = false;
            }
        }
        private static void questoes(int questao)
        {
            switch (questao)
            {
                case 1:
                    Console.WriteLine("");
                    Console.WriteLine("Questão I:");
                    Console.WriteLine("Dado um array de números inteiros, retorne os índices dos dois números de forma que eles se somem a um alvo especíﬁco.");
                    Console.WriteLine("----------------------------------------------------------------");
                    Console.WriteLine("Solução:");
                    // Teste OK
                    int[] numerosOK = { 2, 7, 11, 15 };
                    questao1(numerosOK, 9);
                    // Teste NAO OK
                    int[] numerosNOK = { 6, 7, 11, 15 };
                    questao1(numerosNOK, 5);
                    break;
                case 2:
                    Console.WriteLine("");
                    Console.WriteLine("Questão II:");
                    Console.WriteLine("Um bracket é considerado qualquer um dos seguintes caracteres: (, ), {, }, [ ou ].");
                    Console.WriteLine("Dois brackets são considerados um par combinado se o bracket de abertura (isto é, (, [ou {) ocorre à esquerda de um bracket de fechamento (ou seja,),] ou} do mesmo tipo exato. Existem três tipos de pares de brackets : [ ], { } e ( ).");
                    Console.WriteLine("Um par de brackets correspondente não é balanceado se o de abertura e o de fechamento não corresponderem entre si. Por exemplo, { [ ( ] ) } não é balanceado porque o conteúdo entre {e} não é balanceado. O primeiro bracket inclui o de abertura, (, e o segundo inclui um bracket de fechamento desbalanceado,].");
                    Console.WriteLine("Dado sequencias de caracteres, determine se cada sequência de brackets é balanceada. Se uma string estiver balanceada, retorne SIM. Caso contrário, retorne NAO.");
                    Console.WriteLine("----------------------------------------------------------------");
                    Console.WriteLine("Solução:");
                    // Teste SIM
                    questao2("{[()]}");
                    // Teste NAO
                    questao2("{[(])}");
                    // Teste SIM
                    questao2("{{[[(())]]}}");
                    break;
                case 3:
                    Console.WriteLine("");
                    Console.WriteLine("Questão III");
                    Console.WriteLine("Digamos que você tenha um array para o qual o elemento i é o preço de uma determinada ação no dia i.");
                    Console.WriteLine("Se você tivesse permissão para concluir no máximo uma transação (ou seja, comprar uma e vender uma ação), crie um algoritmo para encontrar o lucro máximo.");
                    Console.WriteLine("Note que você não pode vender uma ação antes de comprar.");
                    Console.WriteLine("----------------------------------------------------------------");
                    // Teste OK
                    int[] valoresOK = { 7, 1, 5, 3, 6, 4 };
                    questao3(valoresOK, 2, 5);
                    // Teste NAO OK
                    int[] valoresNOK = { 7, 6, 4, 3, 1 };
                    questao3(valoresNOK, 3, 5);
                    // Teste NAO OK - Dia Invalido
                    int[] valoresNOKDI = { 7, 6, 4, 3, 1 };
                    questao3(valoresNOKDI, 3, 10);
                    break;
                case 4:
                    Console.WriteLine("");
                    Console.WriteLine("Questão IV");
                    Console.WriteLine("Dados n inteiros não negativos representando um mapa de elevação onde a largura de cada barra é 1, calcule quanta água é capaz de reter após a chuva.");
                    Console.WriteLine("----------------------------------------------------------------");
                    //Teste 1
                    int[] valores = { 0, 1, 0, 2, 1, 0, 1, 3, 2, 1, 2, 1 };
                    questao4(valores);
                    //Teste 2
                    int[] valores2 = { 0, 1, 0, 2, 1, 0, 1, 3, 2, 1, 2, 0, 2 };
                    questao4(valores2);
                    break;
                default:
                    Console.WriteLine("");
                    Console.WriteLine("Opção inválida!");
                    break;
            }
            Console.WriteLine("");
            Console.Write("Pressione qualquer tecla para continuar...");
            Console.ReadKey();
            Console.Clear();
        }
        private static void questao1(int[] numeros, int alvo)
        {
            int[] res = Fcn.getIndexs(numeros, alvo);

            // Inicio Console
            Console.WriteLine("");
            Console.WriteLine("Input: [" + string.Join(",", numeros) + "] - Alvo [" + alvo.ToString() + "]");
            if (res != null)
                Console.WriteLine("Output: [" + res[0].ToString() + "," + res[1].ToString() + "]");
            else
                Console.WriteLine("Output: Não localizado.");
        }
        private static void questao2(String brackets)
        {
            char[] arrayBrackets = brackets.ToCharArray();
            String res = Fcn.bracketsOK(arrayBrackets);

            // Inicio Console
            Console.WriteLine("");
            Console.WriteLine("Input: " + brackets);
            Console.WriteLine("Output: " + res);
        }
        private static void questao3(int[] valores, int diaCompra, int diaVenda)
        {
            Dictionary<string, int> res = Fcn.lucroVenda(valores, diaCompra, diaVenda);

            // Inicio Console
            Console.WriteLine("");
            Console.WriteLine("Input: [" + string.Join(",", valores) + "] - Dias Compra: [" + diaCompra + "] - Dia Venda: [" + diaVenda + "]");
            if (res["valorLucro"] > 0)
                Console.WriteLine("Output: " + res["valorLucro"] + " (Comprou no dia " + diaCompra + " (preço igual a " + res["valorCompra"] + ") e vendeu no dia " + diaVenda + " (preço igual a " + res["valorVenda"] + "), lucro foi de " + res["valorVenda"] + " – " + res["valorCompra"] + " = " + res["valorLucro"]);
            else if (res["valorLucro"] == 0)
                Console.WriteLine("Output: 0 (Nesse caso nenhuma transação deve ser feita, lucro máximo igual a 0)");
            else
                Console.WriteLine("Output: Os dias informados não foram localizados.");
        }
        private static void questao4(int[] valores)
        {
            int res = Fcn.getAguaRetida(valores);

            // Inicio Console
            Console.WriteLine("");
            Console.WriteLine("Input: [" + string.Join(",", valores) + "]");
            Console.WriteLine("Output: " + res);
        }

        internal class Fcn
        {
            public static int[] getIndexs(int[] numeros, int alvo)
            {
                for (int i = 0; i < numeros.Length; i++)
                {
                    int index = ((alvo - numeros[i]) >= 0) ? Array.IndexOf(numeros, alvo - numeros[i]) : 0;
                    if ((index != i) && (index > 0))
                    {
                        int[] res = { i, index };
                        return res;
                    }
                }
                return null;
            }

            public static String bracketsOK(char[] brackets)
            {
                String[] bracketAbertura = { "{", "[", "(" };
                String[] bracketFechamento = { "}", "]", ")" };
                
                for (int i = 0; i < brackets.Length; i++)
                {
                    int idx = Array.IndexOf(bracketAbertura, brackets[i].ToString());
                    if (idx < 0)
                        continue;
                    if (!brackets[(brackets.Length) - (i + 1)].ToString().Equals(bracketFechamento[idx]))
                        return "NAO";
                }

                return "SIM";
            }

            public static Dictionary<string, int> lucroVenda(int[] valores, int diaCompra, int diaVenda)
            {
                Dictionary<string, int> res = new Dictionary<string, int>();
                res["valorCompra"] = -1;
                res["valorVenda"] = -1;
                res["valorLucro"] = -1;

                if ((diaCompra > (valores.Length + 1)) || (diaCompra < 0) || (diaVenda > (valores.Length + 1)) || (diaVenda < 0))
                    return res;

                res["valorCompra"] = valores[(diaCompra - 1)];
                res["valorVenda"] = valores[(diaVenda - 1)];
                res["valorLucro"] = res["valorVenda"] >= res["valorCompra"] ? res["valorVenda"] - res["valorCompra"] : 0;

                return res;
            }

            public static int getMaiorAntes(int[] valores, int posicao)
            {
                int maior = 0;
                for (int i = (posicao-1); i >= 0; i--)
                {
                    if (valores[i] > maior)
                        maior = valores[i];
                    if (valores[i] < maior)
                        return maior;
                }

                return maior;
            }
            public static int getMaiorDepois(int[] valores, int posicao)
            {
                int maior = 0;
                for (int i = (posicao+1); i < valores.Length; i++)
                {
                    if (valores[i] > maior)
                        maior = valores[i];
                    if (valores[i] < maior)
                        return maior;
                }
                return maior;
            }
            public static int getAguaRetida(int[] valores)
            {
                int maiorAntes = 0;
                int maiorDepois = 0;
                int res = 0;
                for (int i = 0; i < valores.Length; i++)
                {
                    maiorAntes = Fcn.getMaiorAntes(valores, i);
                    maiorDepois = Fcn.getMaiorDepois(valores, i);
                    if ((maiorAntes > valores[i]) && (maiorDepois > valores[i]))
                    {
                        res = res + ((maiorAntes < maiorDepois) ? (maiorAntes - valores[i]) : (maiorDepois - valores[i]));
                    }
                }
                return res;
            }
        }
    }
}
