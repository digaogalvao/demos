﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiContato.Models;
using WebApiContato.Service;

namespace WebApiContato.Controllers
{
    [Route("contatos")]
    public class ContatoController : Controller
    {
        private readonly IContatoService service;

        public ContatoController(IContatoService service)
        {
            this.service = service;
        }

        [HttpGet]
        public IActionResult Get()
        {
            var model = service.GetContatos();
            return Ok(model);
        }

        [HttpGet("{id}", Name = "GetContato")]
        public IActionResult Get(int id)
        {
            var model = service.GetContato(id);
            if (model == null)
                return NotFound();

            return Ok(model);
        }

        [HttpPost]
        public IActionResult Create([FromBody]Contato inputModel)
        {
            DetailHttp detail = new DetailHttp();

            if (inputModel == null)
            {
                detail.code = "204";
                detail.message = "Contato não informado!";
                return NotFound(detail);
            }

            service.AddContato(inputModel);

            detail.code = "201";
            detail.message = "Contato criado com sucesso!";
            return Ok(detail);
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody]Contato inputModel)
        {
            DetailHttp detail = new DetailHttp();

            if (id == 0)
            {
                detail.code = "400";
                detail.message = "Id Contato não informado!";
                return NotFound(detail);
            }

            if (inputModel == null)
            {
                detail.code = "204";
                detail.message = "Contato não informado!";
                return NotFound(detail);
            }

            if (!service.ContatoExists(id))
            {
                detail.code = "404";
                detail.message = "Contato inexistente!";
                return NotFound(detail);
            }

            service.UpdateContato(inputModel);

            detail.code = "200";
            detail.message = "Contato atualizado com sucesso!";
            return Ok(detail);
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            DetailHttp detail = new DetailHttp();

            if (!service.ContatoExists(id))
            {
                detail.code = "404";
                detail.message = "Contato inexistente!";
                return NotFound(detail);
            }

            service.DeleteContato(id);

            detail.code = "200";
            detail.message = "Contato excluido com sucesso!";
            return Ok(detail);
        }

    }
}
