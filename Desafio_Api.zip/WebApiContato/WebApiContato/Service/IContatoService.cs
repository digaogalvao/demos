﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiContato.Models;

namespace WebApiContato.Service
{
    public interface IContatoService
    {
        List<Contato> GetContatos();
        Contato GetContato(int id);
        void AddContato(Contato contato);
        void UpdateContato(Contato contato);
        void DeleteContato(int id);
        bool ContatoExists(int id);
    }
}
