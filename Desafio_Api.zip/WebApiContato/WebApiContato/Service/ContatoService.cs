﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiContato.Models;

namespace WebApiContato.Service
{
    public class ContatoService : IContatoService
    {
        private readonly List<Contato> contatos;

        public ContatoService()
        {
            this.contatos = new List<Contato>
            {
                new Contato { Id = 1, Nome = "Rodrigo", Canal = "Celular", Valor = "9999-9999", Obs = "corporativo"},
                new Contato { Id = 2, Nome = "Thiago", Canal = "Fixo", Valor = "2222-2222", Obs = "residencial"},
                new Contato { Id = 3, Nome = "Lucas", Canal = "Email", Valor = "lucas@lucas.com", Obs = "pessoal"}
            };
        }

        public void AddContato(Contato contato)
        {
            this.contatos.Add(contato);
        }

        public bool ContatoExists(int id)
        {
            return this.contatos.Any(m => m.Id == id);
        }

        public void DeleteContato(int id)
        {
            var model = this.contatos.Where(m => m.Id == id).FirstOrDefault();
            this.contatos.Remove(model);
        }

        public Contato GetContato(int id)
        {
            return this.contatos.Where(m => m.Id == id).FirstOrDefault();
        }

        public List<Contato> GetContatos()
        {
            return this.contatos.ToList();
        }

        public void UpdateContato(Contato contato)
        {
            var model = this.contatos.Where(m => m.Id == contato.Id).FirstOrDefault();

            model.Nome = contato.Nome;
            model.Canal = contato.Canal;
            model.Valor = contato.Valor;
            model.Obs = contato.Obs;
        }
    }
}
